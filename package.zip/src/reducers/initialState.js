export default {
  stuff: []
};